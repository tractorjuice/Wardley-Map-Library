# Introduction to Wardley Mapping

<!--
author:  Your Name
email:   your.email@example.com
version: 0.1.0
language: en
narrator: US English Female
comment: A brief introduction to Wardley Mapping
tags: strategy, business, planning
-->

## What is Wardley Mapping?

Wardley Mapping is a strategic planning technique developed by Simon Wardley that helps organizations visualize their business environment and make better strategic decisions.

?[Simon Wardley explaining Wardley Maps](https://www.youtube.com/watch?v=Ty6pOVEc3bA)

## The Basic Structure

A Wardley Map consists of:

1. **Vertical Axis** - Value Chain: 
   - Top: User needs
   - Bottom: Supporting components

2. **Horizontal Axis** - Evolution:
   - Genesis (novel, uncertain)
   - Custom-built (emerging)
   - Product (standardized)
   - Commodity/Utility (ubiquitous)

![Wardley Map Structure](https://upload.wikimedia.org/wikipedia/commons/thumb/8/89/Wardley_map_template.svg/640px-Wardley_map_template.svg.png)

## Interactive Exercise

Let's try to place some IT components on an evolution axis:

[[Custom built] [Product] [Commodity]]
[( ) ( ) (X)] Internet connectivity
[( ) (X) ( )] Customer Relationship Management (CRM) software
[(X) ( ) ( )] Company-specific AI research

## Why Use Wardley Maps?

Wardley Maps help you:

- Visualize your business landscape
- Identify strategic opportunities
- Make better investment decisions
- Anticipate market changes
- Communicate strategy effectively

## Quiz

What does the horizontal axis in a Wardley Map represent?

[[ ]] The importance of components
[[ ]] The cost of components
[[X]] The evolution of components
[[ ]] The complexity of components

## Simple Map Example

```mermaid
graph TD
    Customer((Customer)) --> Website
    Customer --> MobileApp
    Website --> UserDatabase
    MobileApp --> UserDatabase
    Website --> PaymentSystem
    MobileApp --> PaymentSystem
    PaymentSystem --> BankingServices
    
    classDef genesis fill:#ff7f0e;
    classDef custom fill:#1f77b4;
    classDef product fill:#2ca02c;
    classDef commodity fill:#d62728;
    
    class Customer,BankingServices commodity;
    class UserDatabase,PaymentSystem product;
    class Website,MobileApp custom;
```

## Next Steps

To learn more about Wardley Mapping:

1. Read Simon Wardley's book: "Finding a Path"
2. Practice creating maps of your own business
3. Join the Wardley Mapping community

<h2>Try It Yourself!</h2>

Think about your own organization or a service you use regularly. Try to:

1. Identify the user needs
2. Map out the value chain components
3. Position each component on the evolution axis
4. Share your map with colleagues for discussion

<!-- 
You can include this interactive element where users can drag components to create their own simple map
-->

## Notes

The power of Wardley Mapping comes from making the invisible visible. By mapping out your business landscape, you create a shared visual language for strategic discussion.

Remember: There is no "perfect" map - the value comes from the conversations and insights the mapping process generates.
